Android **Expandable List View** Tutorial

[Tutorial](http://www.androidtutorialshub.com/android-expandable-list-view-tutorial/)

[Video Demo](https://www.youtube.com/watch?v=iUb0GLy8Ysk)

[Facebook](https://www.facebook.com/androidtutorialshub)

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.me/AndroidTutorialsHub)

![ExpandableListView](http://www.androidtutorialshub.com/wp-content/uploads/2018/06/0de9c837-bac0-4c60-8754-4b6095c35d74.png)
![ExpandableListView expanded](http://www.androidtutorialshub.com/wp-content/uploads/2018/06/c37b38f7-1bfd-47d3-b344-4589ce4ab7bf.png)
![ExpandableListView child clicked](http://www.androidtutorialshub.com/wp-content/uploads/2018/06/7ebbd9d9-b561-4bb6-b0dc-a834c52e6520.png)
